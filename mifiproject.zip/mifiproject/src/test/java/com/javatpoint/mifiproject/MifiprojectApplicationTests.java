package com.javatpoint.mifiproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MifiprojectApplicationTests {

	@Test
	void contextLoads() {
	}

}
