package com.javatpoint.mifiproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MifiprojectApplication {

	public static void main(String[] args) {
		SpringApplication.run(MifiprojectApplication.class, args);
	}

}
